package service;

import model.Inventory;
import model.Flower;
import model.Money;
import java.util.Scanner;

public class FlowerService {
    private Inventory inventory;

    public FlowerService(Inventory inventory) {
        this.inventory = inventory;
    }

    public void addFlowerToInventory() {
        String name = getFlowerNameFromUser();
        Money price = getFlowerPriceFromUser();
        int quantity = getFlowerQuantityFromUser();

        Flower flower = new Flower(name, price, quantity);
        inventory.addFlower(flower);
        System.out.println("Bunga berhasil ditambahkan!");
    }
    private String getFlowerNameFromUser() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Masukkan nama bunga: ");
        return scanner.nextLine();
    }
    private Money getFlowerPriceFromUser() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Masukkan harga bunga: ");
        double price = scanner.nextDouble();
        return new Money(price);
    }
    private int getFlowerQuantityFromUser() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Masukkan jumlah bunga: ");
        return scanner.nextInt();
    }

    public void displayInventory() {
        inventory.displayInventory();
    }

    public void reduceFlowerQuantity(String flowerName, int quantity) {
        Flower flower = inventory.findFlowerByName(flowerName);
        if (flower != null) {
            flower.reduceQuantity(quantity);
            System.out.println("Jumlah bunga berhasil diperbarui!");
        } else {
            System.out.println("Bunga tidak ditemukan.");
        }
    }
}
