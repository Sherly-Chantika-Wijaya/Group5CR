package service;

import model.Inventory;

public class InventoryService {
    private Inventory inventory;

    public InventoryService(Inventory inventory) {
        this.inventory = inventory;
    }

    public void showInventory() {
        inventory.displayInventory();
    }
}
