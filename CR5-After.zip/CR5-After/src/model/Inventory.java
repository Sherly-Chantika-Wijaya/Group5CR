package model;

import java.util.List;
import java.util.ArrayList;

public class Inventory {
    private List<Flower> flowers;

    public Inventory() {
        flowers = new ArrayList<>();
    }

    public void addFlower(Flower flower) {
        flowers.add(flower);
    }

    public Flower findFlowerByName(String name) {
        for (Flower flower : flowers) {
            if (flower.getName().equalsIgnoreCase(name)) {
                return flower;
            }
        }
        return null;
    }

    public void displayInventory() {
        for (Flower flower : flowers) {
            System.out.println(flower.getName() + " - " + flower.getPrice() + " - Stok: " + flower.getQuantity());
        }
    }
}
