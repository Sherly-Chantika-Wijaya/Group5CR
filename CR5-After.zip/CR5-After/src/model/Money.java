package model;

public class Money {
    private double amount;

    public Money(double amount) {
        this.amount = amount;
    }

    public double getAmount() {
        return amount;
    }

    public Money multiply(int quantity) {
        return new Money(amount * quantity);
    }

    @Override
    public String toString() {
        return "Rp " + String.format("%,.2f", amount);
    }
}